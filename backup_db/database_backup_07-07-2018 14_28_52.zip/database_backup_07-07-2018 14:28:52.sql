#
# TABLE STRUCTURE FOR: anggota
#

DROP TABLE IF EXISTS `anggota`;

CREATE TABLE `anggota` (
  `id_anggota` varchar(25) NOT NULL,
  `nama_anggota` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `foto` varchar(25) NOT NULL DEFAULT 'avatar_placeholder.jpg',
  `register_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id_anggota`),
  KEY `no_hp` (`no_hp`),
  CONSTRAINT `anggota_ibfk_1` FOREIGN KEY (`no_hp`) REFERENCES `login` (`no_hp`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `anggota` (`id_anggota`, `nama_anggota`, `no_hp`, `foto`, `register_time`, `update_time`) VALUES (ADM-1310512042, Admin, 1310512042, avatar_placeholder.jpg, NULL, NULL);
INSERT INTO `anggota` (`id_anggota`, `nama_anggota`, `no_hp`, `foto`, `register_time`, `update_time`) VALUES (B-089687610639, Bernand, 089687610639, avatar_placeholder.jpg, 2018-07-07 14:22:11, NULL);


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `no_hp` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `verifikasi` enum('1','0') NOT NULL DEFAULT '0',
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `level` enum('Admin','Anggota') NOT NULL DEFAULT 'Anggota',
  `login_time` datetime DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL,
  `register_time` datetime DEFAULT NULL,
  `verifikasi_time` datetime DEFAULT NULL,
  `reset_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `token` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_hp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `login` (`no_hp`, `password`, `verifikasi`, `status`, `level`, `login_time`, `logout_time`, `register_time`, `verifikasi_time`, `reset_time`, `updated_time`, `updated_by`, `token`) VALUES (087788104998, 0ef4a8c12755cf68e47a72a35222d103, 0, 1, Anggota, NULL, NULL, 2018-05-27 21:17:04, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `login` (`no_hp`, `password`, `verifikasi`, `status`, `level`, `login_time`, `logout_time`, `register_time`, `verifikasi_time`, `reset_time`, `updated_time`, `updated_by`, `token`) VALUES (087889437578, b9181e954b096020d0d91836c7352a4b, 0, 1, Anggota, NULL, NULL, 2018-07-07 14:27:05, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `login` (`no_hp`, `password`, `verifikasi`, `status`, `level`, `login_time`, `logout_time`, `register_time`, `verifikasi_time`, `reset_time`, `updated_time`, `updated_by`, `token`) VALUES (089687610639, 756d3bdb0433dc8687427559b03d0f5b, 0, 1, Anggota, 2018-07-07 14:22:00, NULL, 2018-07-07 14:20:50, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `login` (`no_hp`, `password`, `verifikasi`, `status`, `level`, `login_time`, `logout_time`, `register_time`, `verifikasi_time`, `reset_time`, `updated_time`, `updated_by`, `token`) VALUES (1310512042, e10adc3949ba59abbe56e057f20f883e, 1, 1, Admin, 2018-07-07 14:05:49, 2018-07-02 14:30:51, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: master_barang
#

DROP TABLE IF EXISTS `master_barang`;

CREATE TABLE `master_barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(50) NOT NULL,
  `qty` varchar(5) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `deleted_by` varchar(100) DEFAULT NULL,
  `deleted` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_barang`),
  KEY `kategori` (`id_kategori`),
  CONSTRAINT `master_barang_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `master_kategori` (`id_kategori`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `master_barang` (`id_barang`, `nama_barang`, `qty`, `id_kategori`, `created_time`, `created_by`, `updated_time`, `updated_by`, `deleted_time`, `deleted_by`, `deleted`) VALUES (1, Spidol, 50, 1, 2018-05-24 11:14:39, 1310512042, 2018-05-24 15:45:28, 1310512042, NULL, NULL, 0);
INSERT INTO `master_barang` (`id_barang`, `nama_barang`, `qty`, `id_kategori`, `created_time`, `created_by`, `updated_time`, `updated_by`, `deleted_time`, `deleted_by`, `deleted`) VALUES (2, Kokoru, 30, 1, 2018-05-27 21:20:11, 1310512042, NULL, NULL, NULL, NULL, 0);


#
# TABLE STRUCTURE FOR: master_kategori
#

DROP TABLE IF EXISTS `master_kategori`;

CREATE TABLE `master_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(50) NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `deleted_by` varchar(100) DEFAULT NULL,
  `deleted` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `master_kategori` (`id_kategori`, `nama_kategori`, `created_time`, `created_by`, `updated_time`, `updated_by`, `deleted_time`, `deleted_by`, `deleted`) VALUES (1, ATK, 2018-05-24 11:14:00, 1310512042, NULL, NULL, NULL, NULL, 0);
INSERT INTO `master_kategori` (`id_kategori`, `nama_kategori`, `created_time`, `created_by`, `updated_time`, `updated_by`, `deleted_time`, `deleted_by`, `deleted`) VALUES (2, Kokoru Foam, 2018-05-27 21:19:51, 1310512042, NULL, NULL, NULL, NULL, 0);


#
# TABLE STRUCTURE FOR: smsgateway_callback
#

DROP TABLE IF EXISTS `smsgateway_callback`;

CREATE TABLE `smsgateway_callback` (
  `id_callback` int(11) NOT NULL AUTO_INCREMENT,
  `no_hp` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `callback` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_callback`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (1, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (2, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (3, 087788104998, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (4, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (5, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (6, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (7, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (8, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (9, 089687610639, 1);
INSERT INTO `smsgateway_callback` (`id_callback`, `no_hp`, `callback`) VALUES (10, 087889437578, 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id_stock` char(8) NOT NULL,
  `id_barang` char(6) NOT NULL,
  `qty` int(11) NOT NULL,
  `sign` varchar(5) NOT NULL,
  `keterangan` varchar(25) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id_stock`),
  KEY `id_barang` (`id_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: transaksi_stock
#

DROP TABLE IF EXISTS `transaksi_stock`;

CREATE TABLE `transaksi_stock` (
  `id_barang` int(11) NOT NULL,
  `in_stock` int(11) DEFAULT NULL,
  `out_stock` int(11) DEFAULT NULL,
  `on_stock` int(11) DEFAULT NULL,
  `stock_before` int(11) DEFAULT NULL,
  `sign` varchar(5) NOT NULL,
  `keterangan` varchar(25) DEFAULT NULL,
  `notes` varchar(250) NOT NULL DEFAULT '-',
  `created_time` datetime NOT NULL,
  `created_by` varchar(15) NOT NULL,
  KEY `id_barang` (`id_barang`),
  CONSTRAINT `transaksi_stock_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `master_barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (1, NULL, 3, 47, 50, HA, Mengurangi Stock, Untuk Nulis, 2018-05-24 11:17:46, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (1, 1, NULL, 48, 47, HA, Menambahkan Stock, -, 2018-05-24 11:18:35, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (1, NULL, 3, 47, 50, HA, Mengurangi Stock, -, 2018-05-25 07:58:33, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (1, 3, NULL, 50, 47, HA, Menambahkan Stock, Untuk Keperluan Mengajar, 2018-05-27 21:22:27, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (2, NULL, 3, 27, 30, HA, Mengurangi Stock, Hara Hetta, 2018-06-06 09:45:13, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (2, 1, NULL, 28, 27, HA, Menambahkan Stock, Apa Yah, 2018-06-06 09:46:54, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (2, NULL, 1, 27, 28, HA, Mengurangi Stock, Tes, 2018-06-11 15:58:56, 089687610639);
INSERT INTO `transaksi_stock` (`id_barang`, `in_stock`, `out_stock`, `on_stock`, `stock_before`, `sign`, `keterangan`, `notes`, `created_time`, `created_by`) VALUES (2, 3, NULL, 30, 27, HA, Menambahkan Stock, -, 2018-06-11 15:59:05, 089687610639);


