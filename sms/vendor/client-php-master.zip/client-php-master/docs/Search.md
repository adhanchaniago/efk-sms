# Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**\SMSGatewayMe\Client\Model\SearchFilter[][]**](array.md) |  | [optional] 
**orderBy** | [**\SMSGatewayMe\Client\Model\SearchOrderBy[]**](SearchOrderBy.md) |  | [optional] 
**limit** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


