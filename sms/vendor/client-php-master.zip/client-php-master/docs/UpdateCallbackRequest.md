# UpdateCallbackRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**event** | **string** |  | [optional] 
**deviceId** | **int** |  | [optional] 
**filterType** | **string** |  | [optional] 
**filter** | **string** |  | [optional] 
**method** | **string** |  | [optional] 
**action** | **string** |  | [optional] 
**secret** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


